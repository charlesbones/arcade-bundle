# 🕹️ Modulino HID Bridge (Arcade Machine)

Turn physical Modulino inputs into mouse movements and keystrokes on any desktop, with a live web UI for full configuration. Designed for arcade-style setups where Modulino hardware controls a RetroArch kiosk or any other application.

---

## Hardware required

- **Arduino UNO Q** — runs the sketch and the Python bridge side-by-side
- **Modulino Buttons** *(optional)* — 3 tactile buttons, each mappable to a mouse click or key
- **Modulino Joystick** *(optional)* — analog stick for relative mouse movement or D-pad arrow keys
- **Modulino Knob** *(optional)* — rotary encoder mapped to scroll wheel or any key
- **Modulino Distance** *(optional)* — proximity trigger for near/far events
- **Modulino Movement** *(optional)* — IMU tilt-to-mouse or tilt-to-D-pad control
- **Modulino Vibro** *(optional)* — haptic confirmation pulse on every action

Any combination of the above can be connected at once; the sketch auto-discovers all nodes on the I²C bus at startup.

---

## How it works

Four pieces talk to each other in a chain:

1. **Arduino sketch** (`sketch/sketch.ino`): scans the Qwiic/I²C bus on boot, classifies every device by address, and polls each one every 16 ms. On any state change it pushes a typed event to Python via `Bridge.notify` (`btn_event`, `joy_event`, `knob_event`, `dist_event`, `imu_event`). It also exposes RPC methods (`apply_settings`, `configure_device`, `vibrate`, `rescan`) that Python can call.
2. **Python app** (`python/main.py`): receives MCU events via `Bridge.provide`, translates them into HID action messages (mouse move, mouse click, key tap/hold, scroll), and sends those messages as UDP JSON packets to the host injector on port 5555. It also serves a REST + Socket.IO web UI for device discovery and configuration, and persists settings and keymap to `python/config.json`.
3. **Browser UI** (`ui/index.html`): a management dashboard that lets you assign actions to each input, tune joystick sensitivity and D-pad behaviour, toggle HID output, and watch live sensor data — all via the REST API exposed by the Python app.
4. **Host injector** (`host/injector.py`): listens on UDP port 5555 and injects events into the OS via `/dev/uinput` (mouse moves, clicks, key taps/holds, scroll wheel). Runs as a systemd user service (`hid-injector.service`) that starts automatically on login. Requires `python-evdev`.

---

## Features

### Dynamic device discovery
The sketch scans the I²C bus at startup and classifies every Modulino node by its address. Unknown addresses are surfaced in the UI so you can assign a type manually without touching the code. A **Rescan** button re-runs discovery at any time.

### Flexible input mapping
Every button, joystick push, knob tick, and proximity zone maps to an independently configurable action: mouse button tap or hold, key tap or hold (with CTRL/SHIFT/ALT modifiers), or scroll wheel. Per-device settings (knob invert direction, distance thresholds, IMU sensitivity) are shown alongside the input mappings in the **Input mapping** section. Mappings and settings are saved to disk and restored on restart.

### Joystick modes
The joystick defaults to **D-Pad** mode, which translates stick deflection past a configurable threshold into arrow key presses with auto-repeat. It can also operate in **Relative** mode (deflection → pixel delta with configurable sensitivity and acceleration).

### IMU tilt control
The Movement module can drive the mouse or D-pad from accelerometer tilt, with per-axis sensitivity, inversion, and a dedicated threshold for D-pad mode. A **Mounting rotation** setting (0°, +90°, -90°) rotates the tilt axes to match how the module is physically mounted — use +90/-90 when it's fixed perpendicular to the surface instead of flat.

### Haptic feedback
If a Modulino Vibro is present, a short pulse confirms every triggered action — button press, proximity event, or knob step.

### Persistent configuration
All settings and keymaps are written to `python/config.json` on every save and loaded automatically on startup.

---

## Injector service setup

The injector runs as a systemd user service on the UNO Q. To set it up:

```bash
# Install dependency
pip install evdev

# Create the service
nano ~/.config/systemd/user/hid-injector.service
```

Paste:
```ini
[Unit]
Description=HID injector (uinput bridge)
After=network.target

[Service]
ExecStart=/usr/bin/python3 /home/arduino/ArduinoApps/modulino-hid-bridge/host/injector.py
Restart=on-failure
RestartSec=3

[Install]
WantedBy=default.target
```

```bash
systemctl --user daemon-reload
systemctl --user enable hid-injector.service
systemctl --user start hid-injector.service
```

---

## Project structure

```
modulino-hid-bridge/
├── app.yaml
├── ui/
│   ├── index.html        # Management dashboard (device config, keymap, live data)
│   ├── styles.css        # Dark-theme styles
│   └── app.js            # REST polling, action pickers, device panels
├── sketch/
│   ├── sketch.ino        # MCU: I²C scan, event polling, Bridge RPC handlers
│   └── sketch.yaml       # Platform and library versions
├── python/
│   ├── main.py           # Python bridge: event routing, HID dispatch, REST API
│   ├── config.json       # Persisted settings and keymap (auto-created)
└── host/
    └── injector.py       # UDP→uinput injector, runs as hid-injector.service
```